const app = getApp()
Page({
  data: {
    StatusBar: app.globalData.StatusBar,
    CustomBar: app.globalData.CustomBar,
    Custom: app.globalData.Custom,
    TabCur: 0,
    MainCur: 0,
    VerticalNavTop: 0,
    list: [],
    load: true,
    openid:''
  },
  onLoad() {
    wx.setTabBarStyle({
      "selectedColor":"#254fff",
      "color": "#b2b1b2"
    })
    wx.showLoading({
      title: '加载中...',
      mask: true
    });
    let list = [{}];
    let namelist=['  植物识别','  动物识别','  文字识别','  手写文字','  通用识别','  汽车识别','  菜品识别','  Logo识别',]
    let piclist=['cloud://insight-4ge88q3i50e6c6ab.696e-insight-4ge88q3i50e6c6ab-1304527209/1f9cf10f-40cf-4c38-9b2e-ceca28f798f0.jpeg',
    'cloud://insight-4ge88q3i50e6c6ab.696e-insight-4ge88q3i50e6c6ab-1304527209/images/dongwu.jpg',
    'cloud://insight-4ge88q3i50e6c6ab.696e-insight-4ge88q3i50e6c6ab-1304527209/images/wenzi.png',
    'cloud://insight-4ge88q3i50e6c6ab.696e-insight-4ge88q3i50e6c6ab-1304527209/images/shouxie.jpg',
    'cloud://insight-4ge88q3i50e6c6ab.696e-insight-4ge88q3i50e6c6ab-1304527209/images/wuti.jpg',
    'cloud://insight-4ge88q3i50e6c6ab.696e-insight-4ge88q3i50e6c6ab-1304527209/src=http___pic.wodingche.com_carimg_omlmdcmdv.jpeg&refer=http___pic.wodingche.jpeg',
    'cloud://insight-4ge88q3i50e6c6ab.696e-insight-4ge88q3i50e6c6ab-1304527209/cai.jpeg',
    'cloud://insight-4ge88q3i50e6c6ab.696e-insight-4ge88q3i50e6c6ab-1304527209/src=http___images.missyuan.com_attachments_day_120708_20120708_fc946beb45d61f289e7f8Eae7EtUoL3W.jpg&refer=http___images.missyuan.jpeg']

    let contentlist=['识别超2万种植物和近8千种花卉，返回植物名称及百科信息。',
    '识别近八千种动物，返回动物名称和对应的百科信息。',
    '多场景、多语种的整图文字检测和识别服务，可识别20种语言。',
    '识别各种不规则手写字体,对手写中文、数字进行检测识别。',
    '超过10万类物体和场景识别，返回物体的名称及百科信息。',
    '识别车辆的具体车型。返回车辆的品牌和百科词条信息。',
    '识别超过9千种菜品，适用于识别只含有单个菜品的图片。',
    '准确识别超过2万类商品Logo，识别图片中品牌Logo的名称。']

    let iconlist=['cuIcon-evaluate',
    'cuIcon-explore',
    'cuIcon-wenzi',
    'cuIcon-write',
    'cuIcon-goods',
    'cuIcon-taxi',
    'cuIcon-attentionfavor',
    'cuIcon-brand']

    let bindtaplist=['zhiwu',
    'dongwu',
    'wenzi',
    'shouxie',
    'wuti',
    'car',
    'dish',
    'logo']

    for (let i = 0; i < 8; i++) {
      list[i] = {};
      list[i].name = namelist[i]
      list[i].pic_url=piclist[i]
      list[i].content=contentlist[i]
      list[i].icon=iconlist[i]
      list[i].bindtap=bindtaplist[i]
      list[i].id = i;
    }
    this.setData({
      list: list,
      listCur: list[0]
    }),

    wx.cloud.callFunction({
      name:'helloCloud',
      data:{
        message:'helloCloud',
      }
    }).then(res=>{
      // console.log(res.result.OPENID,'openid')//res就将appid和openid返回了
        //做一些后续操作，不用考虑代码的异步执行问题。
        var openid=res.result.OPENID
        console.log('首页获取的openid',openid)
    })


    if (!wx.cloud) {
      wx.redirectTo({
        url: '../chooseLib/chooseLib',
      })
      return
    }
  },



  // 植物识别
  zhiwu:function(){
    var bindtap ='zhiwu'
    wx.chooseImage({
      count: 1,
      sourceType: ['album', 'camera'],
    success:function(res){
    // tempFilePath可以作为img标签的src属性显示图片
    // console.log(res)
    const tempFilePaths = res.tempFilePaths
    // console.log(tempFilePaths[0])

    let filePath= tempFilePaths[0]
    const cloudPath = `test/${Date.now()} ${filePath.match(/\.[^.]+?$/)}` 
    console.log(cloudPath)

    wx.showLoading({
      title: '上传中...',
    })

    setTimeout(function () {
      wx.hideLoading()
      }, 2000)
      
    wx.cloud.uploadFile({
      cloudPath,
      filePath,

      success:ress=>{
        console.log(ress)
        // 跳转结果页
        wx.navigateTo({
          url: `../result/result?pic=${filePath}&&fileID=${ress.fileID}&&bindtap=${bindtap}`,
        })

      }
    })
    }
    })
  } , 

 // 动物识别
 dongwu:function(){
  var bindtap ='dongwu'
  wx.chooseImage({
    count: 1,
    sourceType: ['album', 'camera'],
  success:function(res){
  // tempFilePath可以作为img标签的src属性显示图片
  // console.log(res)
  const tempFilePaths = res.tempFilePaths
  // console.log(tempFilePaths[0])

  let filePath= tempFilePaths[0]
  const cloudPath = `dongwu/${Date.now()} ${filePath.match(/\.[^.]+?$/)}` 
  console.log(cloudPath)

  wx.showLoading({
    title: '上传中...',
  })

  setTimeout(function () {
    wx.hideLoading()
    }, 2000)

  wx.cloud.uploadFile({
    cloudPath,
    filePath,
    success:ress=>{
      console.log(ress)

      // 跳转结果页
      wx.navigateTo({
        url: `../result/result?pic=${filePath}&&fileID=${ress.fileID}&&bindtap=${bindtap}`,
      })

    }
  })
  }
  })
} , 

 // 汽车识别
 car:function(){
  var bindtap ='car'
  wx.chooseImage({
    count: 1,
    sourceType: ['album', 'camera'],
  success:function(res){
  // tempFilePath可以作为img标签的src属性显示图片
  // console.log(res)
  const tempFilePaths = res.tempFilePaths
  // console.log(tempFilePaths[0])

  let filePath= tempFilePaths[0]
  const cloudPath = `car/${Date.now()} ${filePath.match(/\.[^.]+?$/)}` 
  console.log(cloudPath)

  wx.showLoading({
    title: '上传中...',
  })

  setTimeout(function () {
    wx.hideLoading()
    }, 2000)

  wx.cloud.uploadFile({
    cloudPath,
    filePath,
    success:ress=>{
      console.log(ress)

      // 跳转结果页
      wx.navigateTo({
        url: `../result/result?pic=${filePath}&&fileID=${ress.fileID}&&bindtap=${bindtap}`,
      })

    }
  })
  }
  })
} , 

 // 菜品识别
dish:function(){
  var bindtap ='dish'
  wx.chooseImage({
    count: 1,
    sourceType: ['album', 'camera'],
  success:function(res){
  // tempFilePath可以作为img标签的src属性显示图片
  // console.log(res)
  const tempFilePaths = res.tempFilePaths
  // console.log(tempFilePaths[0])

  let filePath= tempFilePaths[0]
  const cloudPath = `dish/${Date.now()} ${filePath.match(/\.[^.]+?$/)}` 
  console.log(cloudPath)

  wx.showLoading({
    title: '上传中...',
  })

  setTimeout(function () {
    wx.hideLoading()
    }, 2000)

  wx.cloud.uploadFile({
    cloudPath,
    filePath,
    success:ress=>{
      console.log(ress)

      // 跳转结果页
      wx.navigateTo({
        url: `../logodish_result/logodish_result?pic=${filePath}&&fileID=${ress.fileID}&&bindtap=${bindtap}`,
      })

    }
  })
  }
  })
} , 

 // 货币识别
 huobi:function(){
  var bindtap ='huobi'
  wx.chooseImage({
    count: 1,
    sourceType: ['album', 'camera'],
  success:function(res){
  // tempFilePath可以作为img标签的src属性显示图片
  // console.log(res)
  const tempFilePaths = res.tempFilePaths
  // console.log(tempFilePaths[0])

  let filePath= tempFilePaths[0]
  const cloudPath = `huobi/${Date.now()} ${filePath.match(/\.[^.]+?$/)}` 
  console.log(cloudPath)

  wx.showLoading({
    title: '上传中...',
  })

  setTimeout(function () {
    wx.hideLoading()
    }, 2000)

  wx.cloud.uploadFile({
    cloudPath,
    filePath,
    success:ress=>{
      console.log(ress)

      // 跳转结果页
      wx.navigateTo({
        url: `../result/result?pic=${filePath}&&fileID=${ress.fileID}&&bindtap=${bindtap}`,
      })

    }
  })
  }
  })
} , 

 // LOGO识别
logo:function(){
  var bindtap ='logo'
  wx.chooseImage({
    count: 1,
    sourceType: ['album', 'camera'],
  success:function(res){
  // tempFilePath可以作为img标签的src属性显示图片
  // console.log(res)
  const tempFilePaths = res.tempFilePaths
  // console.log(tempFilePaths[0])

  let filePath= tempFilePaths[0]
  const cloudPath = `logo/${Date.now()} ${filePath.match(/\.[^.]+?$/)}` 
  console.log(cloudPath)

  wx.showLoading({
    title: '上传中...',
  })

  setTimeout(function () {
    wx.hideLoading()
    }, 2000)

  wx.cloud.uploadFile({
    cloudPath,
    filePath,
    success:ress=>{
      console.log(ress)

      // 跳转结果页
      wx.navigateTo({
        url: `../logodish_result/logodish_result?pic=${filePath}&&fileID=${ress.fileID}&&bindtap=${bindtap}`,
      })

    }
  })
  }
  })
} , 

 // 物体识别
wuti:function(){
  var bindtap ='wuti'
  wx.chooseImage({
    count: 1,
    sourceType: ['album', 'camera'],
  success:function(res){
  // tempFilePath可以作为img标签的src属性显示图片
  // console.log(res)
  const tempFilePaths = res.tempFilePaths
  // console.log(tempFilePaths[0])

  let filePath= tempFilePaths[0]
  const cloudPath = `wuti/${Date.now()} ${filePath.match(/\.[^.]+?$/)}` 
  console.log(cloudPath)

  wx.showLoading({
    title: '上传中...',
  })

  setTimeout(function () {
    wx.hideLoading()
    }, 2000)

  wx.cloud.uploadFile({
    cloudPath,
    filePath,
    success:ress=>{
      console.log(ress)

      // 跳转结果页
      wx.navigateTo({
        url: `../result/result?pic=${filePath}&&fileID=${ress.fileID}&&bindtap=${bindtap}`,
      })

    }
  })
  }
  })
} , 

 // 文字识别
 wenzi:function(){
  var bindtap ='wenzi'
  wx.chooseImage({
    count: 1,
    sourceType: ['album', 'camera'],
  success:function(res){
  // tempFilePath可以作为img标签的src属性显示图片
  // console.log(res)
  const tempFilePaths = res.tempFilePaths
  // console.log(tempFilePaths[0])

  let filePath= tempFilePaths[0]
  const cloudPath = `ocr/${Date.now()} ${filePath.match(/\.[^.]+?$/)}` 
  console.log(cloudPath)

  wx.showLoading({
    title: '上传中...',
  })

  setTimeout(function () {
    wx.hideLoading()
    }, 2000)

  wx.cloud.uploadFile({
    cloudPath,
    filePath,
    success:ress=>{
      console.log(ress)

      // 跳转结果页
      wx.navigateTo({
        url: `../ocr_result/ocr_result?pic=${filePath}&&fileID=${ress.fileID}&&bindtap=${bindtap}`,
      })

    }
  })
  }
  })
} , 

 // 手写文字识别
 shouxie:function(){
  var bindtap ='shouxie'
  wx.chooseImage({
    count: 1,
    sourceType: ['album', 'camera'],
  success:function(res){
  // tempFilePath可以作为img标签的src属性显示图片
  // console.log(res)
  const tempFilePaths = res.tempFilePaths
  // console.log(tempFilePaths[0])

  let filePath= tempFilePaths[0]
  const cloudPath = `ocr/${Date.now()} ${filePath.match(/\.[^.]+?$/)}` 
  console.log(cloudPath)

  wx.showLoading({
    title: '上传中...',
  })

  setTimeout(function () {
    wx.hideLoading()
    }, 2000)

  wx.cloud.uploadFile({
    cloudPath,
    filePath,
    success:ress=>{
      console.log(ress)

      // 跳转结果页
      wx.navigateTo({
        url: `../ocr_result/ocr_result?pic=${filePath}&&fileID=${ress.fileID}&&bindtap=${bindtap}`,
      })

    }
  })
  }
  })
  },
  onReady() {
    wx.hideLoading()
  },
  tabSelect(e) {
    this.setData({
      TabCur: e.currentTarget.dataset.id,
      MainCur: e.currentTarget.dataset.id,
      VerticalNavTop: (e.currentTarget.dataset.id - 1) * 50
    })
  },
  VerticalMain(e) {
    let that = this;
    let list = this.data.list;
    let tabHeight = 0;
    if (this.data.load) {
      for (let i = 0; i < list.length; i++) {
        let view = wx.createSelectorQuery().select("#main-" + list[i].id);
        view.fields({
          size: true
        }, data => {
          list[i].top = tabHeight;
          tabHeight = tabHeight + data.height;
          list[i].bottom = tabHeight;     
        }).exec();
      }
      that.setData({
        load: false,
        list: list
      })
    }
    let scrollTop = e.detail.scrollTop + 20;
    for (let i = 0; i < list.length; i++) {
      if (scrollTop > list[i].top && scrollTop < list[i].bottom) {
        that.setData({
          VerticalNavTop: (list[i].id - 1) * 50,
          TabCur: list[i].id
        })
        return false
      }
    }
  },
  onShareAppMessage: function () {

  },
})