// miniprogram/pages/result.js
Page({


  /**
   * 页面的初始数据
   */
  data: {

    // canvasHidden:true,     //设置画板的显示与隐藏，画板不隐藏会影响页面正常显示
    //     avatarUrl: '',         //用户头像
    //     nickName: '',          //用户昵称
    //     wxappName: '识相-Insight',    //小程序名称
    //     shareImgPath: '',      
    //     screenWidth: '',       //设备屏幕宽度
    //     description: 'test',    //奖品描述
    //     FilePath:'',           //头像路径



    showView: true,

    // 当前数据
    currentData: {},

    // 打开弹窗
    showModal: false,

    openid: '',
    jieguo: '',
    bindtap: '',
    test: '',
    navigateTitle: " ",
    imgUrl: '',
    pic: '',
    fileID: ''

    //     posterConfig:[{
    //     howSavePopup:true,
    //     width:'300px',
    //     height:'500px',
    //     image:[{x:'20rpx',y:'20rpx',url:'{{fileID}}',width:'500rpx'}],
    //  }],


  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {


    // ----------------海报---------------
    // var that = this
    // var userInfo, nickName, avatarUrl
    // //获取用户信息，头像，昵称之类的数据
    // wx.getUserInfo({
    //     success: function (res) {
    //         console.log(res);
    //         userInfo = res.userInfo
    //         nickName = userInfo.nickName
    //         avatarUrl = userInfo.avatarUrl
    //         that.setData({
    //             avatarUrl: res.userInfo.avatarUrl,
    //             nickName: res.userInfo.nickName,
    //         })
    //         wx.downloadFile({
    //             url: res.userInfo.avatarUrl
    //         })
    //     }
    // })
    // //获取用户设备信息，屏幕宽度
    // wx.getSystemInfo({
    //     success: res => {
    //         that.setData({
    //             screenWidth: res.screenWidth
    //         })
    //         console.log(that.data.screenWidth)
    //     }
    // })




    // var test = options;
    // this.data.test=test


    // -----------转发分享----------
    if (options.share) {

      var data = JSON.parse(decodeURIComponent(options.share));
      console.log('分享进来的信息', data)

      var jieguo = data.jieguo
      var imgUrl = data.imgUrl
      console.log('分享进来的信息jieguo', jieguo)
      // console.log('分享进来的信息imgurl',imgUrl)


      this.setData({
        jieguo: jieguo,
        imgUrl: imgUrl
      })


    } else {


      console.log('不是分享进来的')




      var category = options.category;
      this.data.navigateTitle = category


      showView: (options.showView == "true" ? true : false)
      console.log(options, '结果页options')
      let {
        pic,
        fileID,
        bindtap
      } = options;
      this.setData({
        imgUrl: fileID,
        // pic:pic
      })
      if (typeof (options.bindtap) == 'undefined') {
        this.setData({
          loadModal: false
        })
        setTimeout(() => {
          this.setData({
            loadModal: false
          })
        }, 3500)
      } else {
        this.setData({
          loadModal: true
        })
        setTimeout(() => {
          this.setData({
            loadModal: false
          })
        }, 4000)
      }




      if (bindtap == 'zhiwu') {
        wx.cloud.callFunction({
          name: "baidu",
          data: {
            fileID: fileID
          },
          success: res => {
            console.log(res, "植物")
            this.setData({
              jieguo: res.result.zhiwu.result
            })

            // 数据库
            const db = wx.cloud.database()
            const record = db.collection('record')
            record.add({
              data: {
                pic_url: fileID,
                type: '植物',
                jieguo: res.result.zhiwu.result,
                time: db.serverDate()
              }
            }).then(res => {
              that.getUserList()
            })

          }
        })
      } else if (bindtap === "dongwu") {
        wx.cloud.callFunction({
          name: "baidu_dongwu",
          data: {
            fileID: fileID
          },
          success: res => {
            console.log(res, "动物")
            this.setData({
              jieguo: res.result.dongwu.result,
            })

            // 数据库
            const db = wx.cloud.database()
            // 获取名为“user”的集合引用
            const record = db.collection('record')
            // 向“user”集合中添加一条数据（Promise 风格）
            record.add({
              data: {
                //  openid:openid,
                pic_url: fileID,
                type: '动物',
                jieguo: res.result.dongwu.result,
                // user: that.userInfo,
                // 构造一个服务端时间的引用，我的项目中都是取自己转化后的时间，
                // 取这个时间更加合理，可用于查询条件、更新字段值或新增记录时的字段值
                time: db.serverDate()
              }
            }).then(res => {
              // 添加成功后重新查询列表
              that.getUserList()
            })

          }
        })
      } else if (bindtap === "dish") {
        wx.cloud.callFunction({
          name: "baidu_dish",
          data: {
            fileID: fileID
          },
          success: res => {
            console.log(res, '菜品')
            this.setData({
              jieguo: res.result.dish.result,
            })

            // 获取数据库引用
            const db = wx.cloud.database()
            // 获取名为“user”的集合引用
            const record = db.collection('record')
            // 向“user”集合中添加一条数据（Promise 风格）
            record.add({
              data: {
                //  openid:openid,
                pic_url: fileID,
                type: '菜品',
                jieguo: res.result.dish.result,
                // user: that.userInfo,
                // 构造一个服务端时间的引用，我的项目中都是取自己转化后的时间，
                // 取这个时间更加合理，可用于查询条件、更新字段值或新增记录时的字段值
                time: db.serverDate()
              }
            }).then(res => {
              // 添加成功后重新查询列表
              that.getUserList()
            })

          }
        })
      } else if (bindtap === "car") {
        wx.cloud.callFunction({
          name: "baidu_car",
          data: {
            fileID: fileID
          },
          success: res => {
            console.log(res, '汽车')
            this.setData({
              jieguo: res.result.car.result,
            })

            // 获取数据库引用
            const db = wx.cloud.database()
            // 获取名为“user”的集合引用
            const record = db.collection('record')
            // 向“user”集合中添加一条数据（Promise 风格）
            record.add({
              data: {
                //  openid:openid,
                pic_url: fileID,
                type: '汽车',
                jieguo: res.result.car.result,
                // user: that.userInfo,
                // 构造一个服务端时间的引用，我的项目中都是取自己转化后的时间，
                // 取这个时间更加合理，可用于查询条件、更新字段值或新增记录时的字段值
                time: db.serverDate()
              }
            }).then(res => {
              // 添加成功后重新查询列表
              that.getUserList()
            })

          }
        })
      } else if (bindtap === "huobi") {
        wx.cloud.callFunction({
          name: "baidu_huobi",
          data: {
            fileID: fileID
          },
          success: res => {
            console.log(res, '货币')
            this.setData({
              jieguo: res.result.huobi.result
            })

            // 获取数据库引用
            const db = wx.cloud.database()
            // 获取名为“user”的集合引用
            const record = db.collection('record')
            // 向“user”集合中添加一条数据（Promise 风格）
            record.add({
              data: {
                //  openid:openid,
                pic_url: fileID,
                type: '货币',
                jieguo: res.result.huobi.result,
                // user: that.userInfo,
                // 构造一个服务端时间的引用，我的项目中都是取自己转化后的时间，
                // 取这个时间更加合理，可用于查询条件、更新字段值或新增记录时的字段值
                time: db.serverDate()
              }
            }).then(res => {
              // 添加成功后重新查询列表
              that.getUserList()
            })

          }
        })
      } else if (bindtap === "logo") {
        wx.cloud.callFunction({
          name: "baidu_logo",
          data: {
            fileID: fileID
          },
          success: res => {
            console.log(res, 'logo')
            this.setData({
              jieguo: res.result.logo.result
            })

            // 获取数据库引用
            const db = wx.cloud.database()
            // 获取名为“user”的集合引用
            const record = db.collection('record')
            // 向“user”集合中添加一条数据（Promise 风格）
            record.add({
              data: {
                //  openid:openid,
                pic_url: fileID,
                type: 'Logo',
                jieguo: res.result.logo.result,
                // user: that.userInfo,
                // 构造一个服务端时间的引用，我的项目中都是取自己转化后的时间，
                // 取这个时间更加合理，可用于查询条件、更新字段值或新增记录时的字段值
                time: db.serverDate()
              }
            }).then(res => {
              // 添加成功后重新查询列表
              that.getUserList()
            })

          }
        })
      } else if (bindtap === "wuti") {
        wx.cloud.callFunction({
          name: "baidu_wuti",
          data: {
            fileID: fileID
          },
          success: res => {
            console.log(res, 'wuti')
            this.setData({
              jieguo: res.result.wuti.result,
            })

            // console.log(jieguo,'物体识别')
            // 获取数据库引用
            const db = wx.cloud.database()
            // 获取名为“user”的集合引用
            const record = db.collection('record')
            // 向“user”集合中添加一条数据（Promise 风格）
            record.add({
              data: {
                //  openid:openid,
                pic_url: fileID,
                type: '物体',
                jieguo: res.result.wuti.result,
                // user: that.userInfo,
                // 构造一个服务端时间的引用，我的项目中都是取自己转化后的时间，
                // 取这个时间更加合理，可用于查询条件、更新字段值或新增记录时的字段值
                time: db.serverDate()
              }
            }).then(res => {
              // 添加成功后重新查询列表
              that.getUserList()
            })

          }
        })
      } else if (bindtap === "wenzi") {
        wx.cloud.callFunction({
          name: "baidu_ocr",
          data: {
            fileID: fileID
          },
          success: res => {
            console.log(res, '文字')
            this.setData({
              jieguo: res.result.wenzi.words_result,
            })

            // 获取数据库引用
            const db = wx.cloud.database()
            // 获取名为“user”的集合引用
            const record = db.collection('record')
            // 向“user”集合中添加一条数据（Promise 风格）
            record.add({
              data: {
                //  openid:openid,
                pic_url: fileID,
                type: '文字',
                jieguo: res.result.wenzi.words_result,
                // user: that.userInfo,
                // 构造一个服务端时间的引用，我的项目中都是取自己转化后的时间，
                // 取这个时间更加合理，可用于查询条件、更新字段值或新增记录时的字段值
                time: db.serverDate()
              }
            }).then(res => {
              // 添加成功后重新查询列表
              that.getUserList()
            })

          }
        })
      } else {

        var jieguo_chuan = JSON.parse(options.jieguo)
        console.log(jieguo_chuan, 'json转')
        this.setData({
          jieguo: jieguo_chuan
        })
      }

    }


  },

  showModal(e) {

    this.setData({
      currentData: e.currentTarget.dataset.item,
      showModel: true
    })
    console.log(currentData.name, 'curdata')

  },
  hideModal(e) {
    this.setData({
      showModel: false
    })
  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function (ops) {

    console.log('点击分享后的值', ops)

    var json = encodeURIComponent(JSON.stringify(this.data));

    if (ops.from === 'button') {
      // 来自页面内转发按钮
      console.log(ops.target)
    }
    return {
      title: '🤔 你知道这是什么吗？',
      path: 'pages/result/result?share=' + json,
      success: function (res) {
        // 转发成功
        console.log("转发成功:" + JSON.stringify(res));

      },
      fail: function (res) {
        // 转发失败
        console.log("转发失败:" + JSON.stringify(res));
      }
    }




  },





  // onPosterSuccess(e) {
  //   const { detail } = e;
  //   wx.previewImage({
  //       current: detail,
  //       urls: [detail]
  //   })
  // },

  // onPosterFail(e){
  //   const { detail } = e;
  //   console.log(detail,'错误')
  // },

  to_poster(e) {

    wx.navigateTo({
      url: `../poster/poster?name=${name,keyword}`,
    })
  },

  //定义的保存图片方法
  // saveImageToPhotosAlbum:
  //   function () {
  //       wx.showLoading({
  //           title: '保存中...',
  //       })
  //       var that = this;
  //       //设置画板显示，才能开始绘图
  //       that.setData({
  //           canvasHidden: false
  //       })
  //       var unit = that.data.screenWidth / 375
  //       var path1 = pic_url
  //       var avatarUrl = that.data.avatarUrl
  //       console.log(avatarUrl + "头像")
  //       var path2 = pic_url
  //       var path3 = pic_url
  //       var path4 = pic_url
  //       var path5 = pic_url
  //       var unlight = pic_url
  //       var nickName = that.data.nickName
  //       console.log(nickName + "昵称")
  //       var context = wx.createCanvasContext('share')
  //       var description = that.data.description
  //       var wxappName = "来「 " + that.data.wxappName + " 」试试运气"
  //       context.drawImage(path1, 0, 0, unit * 375, unit * 462.5)
  //       //   context.drawImage(path4, unit * 164, unit * 40, unit * 50, unit * 50)
  //       context.drawImage(path2, unit * 48, unit * 120, unit * 280, unit * 178)
  //       context.drawImage(path5, unit * 48, unit * 120, unit * 280, unit * 178)
  //       context.drawImage(unlight, unit * 82, unit * 145, unit * 22, unit * 32)
  //       context.drawImage(unlight, unit * 178 , unit * 145, unit * 22, unit * 32)
  //       context.drawImage(unlight, unit * 274, unit * 145, unit * 22, unit * 32)
  //       context.drawImage(unlight, unit * 82, unit * 240, unit * 22, unit * 32)
  //       context.drawImage(unlight, unit * 178, unit * 240, unit * 22, unit * 32)
  //       context.drawImage(unlight, unit * 274, unit * 240, unit * 22, unit * 32)
  //       context.drawImage(path3, unit * 20, unit * 385, unit * 55, unit * 55)
  //       //   context.drawImage(path4, 48, 200, 280, 128)
  //       context.setFontSize(14)
  //       context.setFillStyle("#999")
  //       context.fillText("长按识别小程序", unit * 90, unit * 408)
  //       context.fillText(wxappName, unit * 90, unit * 428)
  //       //把画板内容绘制成图片，并回调 画板图片路径
  //       context.draw(false, function () {
  //           wx.canvasToTempFilePath({
  //               x: 0,
  //               y: 0,
  //               width: unit * 375,
  //               height: unit * 462.5,
  //               destWidth: unit * 375,
  //               destHeight: unit * 462.5,
  //               canvasId: 'share',
  //               success: function (res) {
  //                   that.setData({
  //                       shareImgPath: res.tempFilePath
  //                   })
  //                   if (!res.tempFilePath) {
  //                       wx.showModal({
  //                           title: '提示',
  //                           content: '图片绘制中，请稍后重试',
  //                           showCancel: false
  //                       })
  //                   }
  //                   console.log(that.data.shareImgPath)
  //                   //画板路径保存成功后，调用方法吧图片保存到用户相册
  //                   wx.saveImageToPhotosAlbum({
  //                       filePath: res.tempFilePath,
  //                       //保存成功失败之后，都要隐藏画板，否则影响界面显示。
  //                       success: (res) => {
  //                           console.log(res)
  //                           wx.hideLoading()
  //                           that.setData({
  //                               canvasHidden: true
  //                           })
  //                       },
  //                       fail: (err) => {
  //                           console.log(err)
  //                           wx.hideLoading()
  //                           that.setData({
  //                               canvasHidden: true
  //                           })
  //                       }
  //                   })
  //               }
  //           })
  //       });
  //     }






})