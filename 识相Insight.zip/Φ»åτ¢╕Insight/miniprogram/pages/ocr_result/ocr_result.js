// miniprogram/pages/ocr_result.js
Page({

  /**
   * 页面的初始数据
   */
  data: {
    ocr_res:''
  },

  /**
   * 生命周期函数--监听页面加载
   */
    onLoad: function (options) {
      showView: (options.showView == "true" ? true : false)
      console.log(options)
      let { pic , fileID , bindtap,ocr_res} = options;
      this.setData({
        imgUrl:pic,
        ocr_res:ocr_res
      })
      if(typeof(options.bindtap)=='undefined'){
        this.setData({
          loadModal: false
        })
        setTimeout(()=> {
          this.setData({
            loadModal: false
          })
        }, 3500)
      }else{
        this.setData({
          loadModal: true
        })
        setTimeout(()=> {
          this.setData({
            loadModal: false
          })
        }, 3500)
      }


    if (bindtap=='wenzi'){
      wx.cloud.callFunction({
        name:"baidu_ocr",
        data:{
          fileID:fileID
        },
        success:res=>{
          console.log(res,'文字')

          const a= res.result.wenzi.words_result

          var ocr_res=[];
          for(var i=0;i<a.length;i++){
            ocr_res.push(a[i].words+"\n")
          }
          console.log(ocr_res,'拼接')

          var c=ocr_res.join("");

          this.setData({
            // jieguo:res.result.wenzi.words_result,
            ocr_res:c.toString()
          })

          // 获取数据库引用
         const db = wx.cloud.database()
         // 获取名为“user”的集合引用
         const record = db.collection('record')
         // 向“user”集合中添加一条数据（Promise 风格）
         record.add({
           data: {
            //  openid:openid,
             pic_url:fileID,
             type:'文字',
            //  jieguo:res.result.wenzi.words_result,
             ocr_res:c.toString(),
             // user: that.userInfo,
             // 构造一个服务端时间的引用，我的项目中都是取自己转化后的时间，
             // 取这个时间更加合理，可用于查询条件、更新字段值或新增记录时的字段值
             time: db.serverDate()
           }
         }).then(res => {
           // 添加成功后重新查询列表
           that.getUserList()
         })
         
        }
      })
  }
  else{
    wx.cloud.callFunction({
      name:"baidu_shouxie",
      data:{
        fileID:fileID
      },
      success:res=>{
        console.log(res,'手写文字')

        const a= res.result.shouxie.words_result

        var ocr_res=[];
        for(var i=0;i<a.length;i++){
          ocr_res.push(a[i].words+"\n")
        }
        console.log(ocr_res,'拼接')

        var c=ocr_res.join("");

        this.setData({
          // jieguo:res.result.wenzi.words_result,
          ocr_res:c.toString()
        })
        // 获取数据库引用
       const db = wx.cloud.database()
       // 获取名为“user”的集合引用
       const record = db.collection('record')
       // 向“user”集合中添加一条数据（Promise 风格）
       record.add({
         data: {
          //  openid:openid,
           pic_url:fileID,
           type:'手写文字',
          //  jieguo:res.result.wenzi.words_result,
           ocr_res:c.toString(),
           // user: that.userInfo,
           // 构造一个服务端时间的引用，我的项目中都是取自己转化后的时间，
           // 取这个时间更加合理，可用于查询条件、更新字段值或新增记录时的字段值
           time: db.serverDate()
         }
       }).then(res => {
         // 添加成功后重新查询列表
         that.getUserList()
       })
      }
    })
  }},


  textareaAInput(e) {
    this.setData({
      textareaAValue: e.detail.value.toString(),
    })
  },

  CopyLink(e) {


    if (e.currentTarget.dataset.change==undefined){
      wx.setClipboardData({

        data: e.currentTarget.dataset.origin,
        success: res => {
          wx.showToast({
            title: '🌟已复制🌟',
            duration: 1000,
          })
        }
      })
    }else{
      wx.setClipboardData({

        data: e.currentTarget.dataset.change,
        success: res => {
          wx.showToast({
            title: '🌟已复制🌟',
            duration: 1000,
          })
        }
      })
    }
  
  },
  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {

  },

})