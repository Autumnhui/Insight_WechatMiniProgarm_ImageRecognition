//index.js
const app = getApp()

Page({
  data: {
    shows: false,
    StatusBar: app.globalData.StatusBar,
    CustomBar: app.globalData.CustomBar,
    openid:''
  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {

  },

  onLoad: function() {


    wx.cloud.callFunction({
      name:'helloCloud',
      data:{
        message:'helloCloud',
      }
    }).then(res=>{
      // console.log(res.result.OPENID,'openid')//res就将appid和openid返回了
        //做一些后续操作，不用考虑代码的异步执行问题。
        var openid=res.result.OPENID
        console.log('首页获取的openid',openid)
    })


    if (!wx.cloud) {
      wx.redirectTo({
        url: '../chooseLib/chooseLib',
      })
      return
    }
  },



  // 植物识别
  zhiwu:function(){
    var bindtap ='zhiwu'
    wx.chooseImage({
      count: 1,
      sourceType: ['album', 'camera'],
    success:function(res){
    // tempFilePath可以作为img标签的src属性显示图片
    // console.log(res)
    const tempFilePaths = res.tempFilePaths
    // console.log(tempFilePaths[0])

    let filePath= tempFilePaths[0]
    const cloudPath = `test/${Date.now()} ${filePath.match(/\.[^.]+?$/)}` 
    console.log(cloudPath)

    wx.showLoading({
      title: '上传中...',
    })

    setTimeout(function () {
      wx.hideLoading()
      }, 2000)
      
    wx.cloud.uploadFile({
      cloudPath,
      filePath,

      success:ress=>{
        console.log(ress)
        // 跳转结果页
        wx.navigateTo({
          url: `../result/result?pic=${filePath}&&fileID=${ress.fileID}&&bindtap=${bindtap}`,
        })

      }
    })
    }
    })
  } , 

 // 动物识别
 dongwu:function(){
  var bindtap ='dongwu'
  wx.chooseImage({
    count: 1,
    sourceType: ['album', 'camera'],
  success:function(res){
  // tempFilePath可以作为img标签的src属性显示图片
  // console.log(res)
  const tempFilePaths = res.tempFilePaths
  // console.log(tempFilePaths[0])

  let filePath= tempFilePaths[0]
  const cloudPath = `dongwu/${Date.now()} ${filePath.match(/\.[^.]+?$/)}` 
  console.log(cloudPath)

  wx.showLoading({
    title: '上传中...',
  })

  setTimeout(function () {
    wx.hideLoading()
    }, 2000)

  wx.cloud.uploadFile({
    cloudPath,
    filePath,
    success:ress=>{
      console.log(ress)

      // 跳转结果页
      wx.navigateTo({
        url: `../result/result?pic=${filePath}&&fileID=${ress.fileID}&&bindtap=${bindtap}`,
      })

    }
  })
  }
  })
} , 

 // 汽车识别
 car:function(){
  var bindtap ='car'
  wx.chooseImage({
    count: 1,
    sourceType: ['album', 'camera'],
  success:function(res){
  // tempFilePath可以作为img标签的src属性显示图片
  // console.log(res)
  const tempFilePaths = res.tempFilePaths
  // console.log(tempFilePaths[0])

  let filePath= tempFilePaths[0]
  const cloudPath = `car/${Date.now()} ${filePath.match(/\.[^.]+?$/)}` 
  console.log(cloudPath)

  wx.showLoading({
    title: '上传中...',
  })

  setTimeout(function () {
    wx.hideLoading()
    }, 2000)

  wx.cloud.uploadFile({
    cloudPath,
    filePath,
    success:ress=>{
      console.log(ress)

      // 跳转结果页
      wx.navigateTo({
        url: `../result/result?pic=${filePath}&&fileID=${ress.fileID}&&bindtap=${bindtap}`,
      })

    }
  })
  }
  })
} , 

 // 菜品识别
dish:function(){
  var bindtap ='dish'
  wx.chooseImage({
    count: 1,
    sourceType: ['album', 'camera'],
  success:function(res){
  // tempFilePath可以作为img标签的src属性显示图片
  // console.log(res)
  const tempFilePaths = res.tempFilePaths
  // console.log(tempFilePaths[0])

  let filePath= tempFilePaths[0]
  const cloudPath = `dish/${Date.now()} ${filePath.match(/\.[^.]+?$/)}` 
  console.log(cloudPath)

  wx.showLoading({
    title: '上传中...',
  })

  setTimeout(function () {
    wx.hideLoading()
    }, 2000)

  wx.cloud.uploadFile({
    cloudPath,
    filePath,
    success:ress=>{
      console.log(ress)

      // 跳转结果页
      wx.navigateTo({
        url: `../logodish_result/logodish_result?pic=${filePath}&&fileID=${ress.fileID}&&bindtap=${bindtap}`,
      })

    }
  })
  }
  })
} , 

 // 货币识别
 huobi:function(){
  var bindtap ='huobi'
  wx.chooseImage({
    count: 1,
    sourceType: ['album', 'camera'],
  success:function(res){
  // tempFilePath可以作为img标签的src属性显示图片
  // console.log(res)
  const tempFilePaths = res.tempFilePaths
  // console.log(tempFilePaths[0])

  let filePath= tempFilePaths[0]
  const cloudPath = `huobi/${Date.now()} ${filePath.match(/\.[^.]+?$/)}` 
  console.log(cloudPath)

  wx.showLoading({
    title: '上传中...',
  })

  setTimeout(function () {
    wx.hideLoading()
    }, 2000)

  wx.cloud.uploadFile({
    cloudPath,
    filePath,
    success:ress=>{
      console.log(ress)

      // 跳转结果页
      wx.navigateTo({
        url: `../result/result?pic=${filePath}&&fileID=${ress.fileID}&&bindtap=${bindtap}`,
      })

    }
  })
  }
  })
} , 

 // LOGO识别
logo:function(){
  var bindtap ='logo'
  wx.chooseImage({
    count: 1,
    sourceType: ['album', 'camera'],
  success:function(res){
  // tempFilePath可以作为img标签的src属性显示图片
  // console.log(res)
  const tempFilePaths = res.tempFilePaths
  // console.log(tempFilePaths[0])

  let filePath= tempFilePaths[0]
  const cloudPath = `logo/${Date.now()} ${filePath.match(/\.[^.]+?$/)}` 
  console.log(cloudPath)

  wx.showLoading({
    title: '上传中...',
  })

  setTimeout(function () {
    wx.hideLoading()
    }, 2000)

  wx.cloud.uploadFile({
    cloudPath,
    filePath,
    success:ress=>{
      console.log(ress)

      // 跳转结果页
      wx.navigateTo({
        url: `../logodish_result/logodish_result?pic=${filePath}&&fileID=${ress.fileID}&&bindtap=${bindtap}`,
      })

    }
  })
  }
  })
} , 

 // 物体识别
wuti:function(){
  var bindtap ='wuti'
  wx.chooseImage({
    count: 1,
    sourceType: ['album', 'camera'],
  success:function(res){
  // tempFilePath可以作为img标签的src属性显示图片
  // console.log(res)
  const tempFilePaths = res.tempFilePaths
  // console.log(tempFilePaths[0])

  let filePath= tempFilePaths[0]
  const cloudPath = `wuti/${Date.now()} ${filePath.match(/\.[^.]+?$/)}` 
  console.log(cloudPath)

  wx.showLoading({
    title: '上传中...',
  })

  setTimeout(function () {
    wx.hideLoading()
    }, 2000)

  wx.cloud.uploadFile({
    cloudPath,
    filePath,
    success:ress=>{
      console.log(ress)

      // 跳转结果页
      wx.navigateTo({
        url: `../result/result?pic=${filePath}&&fileID=${ress.fileID}&&bindtap=${bindtap}`,
      })

    }
  })
  }
  })
} , 

 // 文字识别
 wenzi:function(){
  var bindtap ='wenzi'
  wx.chooseImage({
    count: 1,
    sourceType: ['album', 'camera'],
  success:function(res){
  // tempFilePath可以作为img标签的src属性显示图片
  // console.log(res)
  const tempFilePaths = res.tempFilePaths
  // console.log(tempFilePaths[0])

  let filePath= tempFilePaths[0]
  const cloudPath = `ocr/${Date.now()} ${filePath.match(/\.[^.]+?$/)}` 
  console.log(cloudPath)

  wx.showLoading({
    title: '上传中...',
  })

  setTimeout(function () {
    wx.hideLoading()
    }, 2000)

  wx.cloud.uploadFile({
    cloudPath,
    filePath,
    success:ress=>{
      console.log(ress)

      // 跳转结果页
      wx.navigateTo({
        url: `../ocr_result/ocr_result?pic=${filePath}&&fileID=${ress.fileID}&&bindtap=${bindtap}`,
      })

    }
  })
  }
  })
} , 

 // 手写文字识别
 shouxie:function(){
  var bindtap ='shouxie'
  wx.chooseImage({
    count: 1,
    sourceType: ['album', 'camera'],
  success:function(res){
  // tempFilePath可以作为img标签的src属性显示图片
  // console.log(res)
  const tempFilePaths = res.tempFilePaths
  // console.log(tempFilePaths[0])

  let filePath= tempFilePaths[0]
  const cloudPath = `ocr/${Date.now()} ${filePath.match(/\.[^.]+?$/)}` 
  console.log(cloudPath)

  wx.showLoading({
    title: '上传中...',
  })

  setTimeout(function () {
    wx.hideLoading()
    }, 2000)

  wx.cloud.uploadFile({
    cloudPath,
    filePath,
    success:ress=>{
      console.log(ress)

      // 跳转结果页
      wx.navigateTo({
        url: `../ocr_result/ocr_result?pic=${filePath}&&fileID=${ress.fileID}&&bindtap=${bindtap}`,
      })

    }
  })
  }
  })
} , 



   /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {

  },

})
