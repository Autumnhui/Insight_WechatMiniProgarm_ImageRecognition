// miniprogram/pages/result.js
Page({


  /**
   * 页面的初始数据
   */
  data: {
    showView: true,

    // 当前数据
    currentData:{},

    // 打开弹窗
    showModal:false,
    imgUrl:'',
    jieguo:''

  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {


    // -----------转发分享----------
    if (options.share){
    
      var data = JSON.parse(decodeURIComponent(options.share));
      console.log('分享进来的信息',data)

      var jieguo = data.jieguo
      var imgUrl = data.imgUrl
      console.log('分享进来的信息jieguo',jieguo)
      console.log('分享进来的信息imgurl',imgUrl)


      this.setData({
        jieguo:jieguo,
        imgUrl:imgUrl
      })


    }else{

   
console.log('不是分享进来的')





    showView: (options.showView == "true" ? true : false)
    console.log(options.bindtap)
    let { pic , fileID , bindtap} = options;
    this.setData({
      imgUrl:fileID
    })
    if(typeof(options.bindtap)=='undefined'){
    this.setData({
      loadModal: false
    })
    setTimeout(()=> {
      this.setData({
        loadModal: false
      })
    }, 3500)
  }else{
    this.setData({
      loadModal: true
    })
    setTimeout(()=> {
      this.setData({
        loadModal: false
      })
    }, 3500)
  }

if(bindtap=='zhiwu'){
  wx.cloud.callFunction({
    name:"baidu",
    data:{
      fileID:fileID
    },
    success:res=>{
      console.log(res,"植物")
      this.setData({
        jieguo:res.result.zhiwu.result
      })
    }
  })
}else if(bindtap === "dongwu"){
  wx.cloud.callFunction({
    name:"baidu_dongwu",
    data:{
      fileID:fileID
    },
    success:res=>{
      console.log(res,"动物")
      this.setData({
        jieguo:res.result.dongwu.result,
      })
    }
  })
}
else if(bindtap === "dish"){
  wx.cloud.callFunction({
    name:"baidu_dish",
    data:{
      fileID:fileID
    },
    success:res=>{
      console.log(res,'菜品')
      this.setData({
        jieguo:res.result.dish.result,
      })

      //数据库
      const db = wx.cloud.database()
      // 获取名为“user”的集合引用
      const record = db.collection('record')
      // 向“user”集合中添加一条数据（Promise 风格）
      record.add({
        data: {
         //  openid:openid,
          pic_url:fileID,
          type:'菜品',
          jieguo:res.result.dish.result,
          // user: that.userInfo,
          // 构造一个服务端时间的引用，我的项目中都是取自己转化后的时间，
          // 取这个时间更加合理，可用于查询条件、更新字段值或新增记录时的字段值
          time: db.serverDate()
        }
      }).then(res => {
        // 添加成功后重新查询列表
        that.getUserList()
      })
    }
  })
}
else if(bindtap === "car"){
  wx.cloud.callFunction({
    name:"baidu_car",
    data:{
      fileID:fileID
    },
    success:res=>{
      console.log(res,'汽车')
      this.setData({
        jieguo:res.result.car.result,
      })
    }
  })
}
else if(bindtap === "huobi"){
  wx.cloud.callFunction({
    name:"baidu_huobi",
    data:{
      fileID:fileID
    },
    success:res=>{
      console.log(res,'货币')
      this.setData({
        jieguo:res.result.huobi.result
      })
    }
  })
}
else if(bindtap === "logo"){
  wx.cloud.callFunction({
    name:"baidu_logo",
    data:{
      fileID:fileID
    },
    success:res=>{
      console.log(res,'logo')
      this.setData({
        jieguo:res.result.logo.result
      })


      // 获取数据库引用
      const db = wx.cloud.database()
      // 获取名为“user”的集合引用
      const record = db.collection('record')
      // 向“user”集合中添加一条数据（Promise 风格）
      record.add({
        data: {
         //  openid:openid,
          pic_url:fileID,
          type:'Logo',
          jieguo:res.result.logo.result,
          // user: that.userInfo,
          // 构造一个服务端时间的引用，我的项目中都是取自己转化后的时间，
          // 取这个时间更加合理，可用于查询条件、更新字段值或新增记录时的字段值
          time: db.serverDate()
        }
      }).then(res => {
        // 添加成功后重新查询列表
        that.getUserList()
      })

    }
  })
}
else if(bindtap === "wuti"){
  wx.cloud.callFunction({
    name:"baidu_wuti",
    data:{
      fileID:fileID
    },
    success:res=>{
      console.log(res,'wuti')
      this.setData({
        jieguo:res.result.wuti.result,
      })
    }
  })
}
else if(bindtap === "wenzi"){
  wx.cloud.callFunction({
    name:"baidu_ocr",
    data:{
      fileID:fileID
    },
    success:res=>{
      console.log(res,'文字')
      this.setData({
        jieguo:res.result.wenzi.words_result,
      })
    }
  })
}

else {

  var jieguo_chuan = JSON.parse(options.jieguo)
  console.log(jieguo_chuan,'json转')
  this.setData({
    jieguo:jieguo_chuan
  })
}
}



  },

  showModal(e) {
    this.setData({
      currentData: e.currentTarget.dataset.item,
      showModel: true
    })
  },
  hideModal(e) {
    this.setData({
      showModel:false
    })
  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function (ops) {

    var json = encodeURIComponent(JSON.stringify(this.data));

    if (ops.from === 'button') {
      // 来自页面内转发按钮
      console.log(ops.target)
    }
    return {
      title: '🤔 你知道这是什么吗？',
      path: 'pages/logodish_result/logodish_result?share=' + json,
      success: function(res) {
        // 转发成功
        console.log("转发成功:" + JSON.stringify(res));

      },
      fail: function(res) {
        // 转发失败
        console.log("转发失败:" + JSON.stringify(res));
      }
    }




  },


})