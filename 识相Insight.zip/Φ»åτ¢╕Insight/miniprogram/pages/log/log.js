const db = wx.cloud.database()

// pages/log/log.js
Page({

  /**
   * 页面的初始数据
   */
  data: {
    openid: '',
    data: '',
    pic_url: '',
    jieguo: '',
    purl: '',
    data_dao: ''
  },


  
  onLoad: function (options) {

    wx.cloud.callFunction({
      name: 'helloCloud',
      data: {
        message: 'helloCloud',
      }
    }).then(res => {

      var openid = res.result.OPENID

      console.log('识别记录页获取的openid', openid)

      //数据库
      db.collection("record").where({
        _openid: res.result.OPENID
      }).orderBy('time', 'desc').get({
        success: res => {
          console.log(res, '查询数据库')
          this.setData({
            data: res.data,
          })
        }
      })

    })



  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {

  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {

  },

  toresult(e) {

    console.log(e, '所有内容')

    let pic_url = e.currentTarget.dataset.item.pic_url
    let jieguo = e.currentTarget.dataset.item.jieguo
    let type = e.currentTarget.dataset.item.type
    let ocr_res = e.currentTarget.dataset.item.ocr_res

    console.log(type, '类型')

    //条件判断type，如果是logo和菜品，跳转到菜品LOGO结果页；如果是文字和手写文字，跳转到文字结果页，else跳转一般结果页。
    
    if (type == 'Logo' || type == '菜品') {
      wx.navigateTo({
        url: `../logodish_result/logodish_result?fileID=${pic_url}&&jieguo=${JSON.stringify(jieguo)}`,
      })

    } else if (type == '文字' || type == '手写文字') {
      wx.navigateTo({
        url: `../ocr_result/ocr_result?pic=${pic_url}&&ocr_res=${ocr_res}`,
      })

    } else {
      wx.navigateTo({
        url: `../result/result?fileID=${pic_url}&&jieguo=${JSON.stringify(jieguo)}`,
      })

    }
  }
})