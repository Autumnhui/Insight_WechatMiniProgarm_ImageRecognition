const db=wx.cloud.database()
Page({
  data: {
    cardCur: 0,
    swiperList: [{
      id: 0,
      type: 'image',
      url: 'https://ossweb-img.qq.com/images/lol/web201310/skin/big84000.jpg'
    }, {
      id: 1,
        type: 'image',
        url: 'https://ossweb-img.qq.com/images/lol/web201310/skin/big84001.jpg',
    }, {
      id: 2,
      type: 'image',
      url: 'https://ossweb-img.qq.com/images/lol/web201310/skin/big39000.jpg'
    }, {
      id: 3,
      type: 'image',
      url: 'https://ossweb-img.qq.com/images/lol/web201310/skin/big10001.jpg'
    }, {
      id: 4,
      type: 'image',
      url: 'https://ossweb-img.qq.com/images/lol/web201310/skin/big25011.jpg'
    }, {
      id: 5,
      type: 'image',
      url: 'https://ossweb-img.qq.com/images/lol/web201310/skin/big21016.jpg'
    }, {
      id: 6,
      type: 'image',
      url: 'https://ossweb-img.qq.com/images/lol/web201310/skin/big99008.jpg'
    }],

    card:'',
    card_r:'',
    id:'',
    swiper:'',
    uknow:'',
    pic_url:''



  },


  onLoad() {
    this.towerSwiper('swiperList');
    // 初始化towerSwiper 传已有的数组名即可


    db.collection("knowledge").get({
      success:res=>{
        console.log(res)
        this.setData({
          card:res.data,
        })
      }
    })

    // db.collection("knowledge").orderBy('num','desc').limit(3).get({
    //   success:res=>{
    //     console.log(res)
    //     this.setData({
    //       swiper:res.data,
    //     })
    //   }
    // })

    db.collection("uknow").get({
      success:res=>{
        console.log('uknow',res)
        this.setData({
          uknow:res.data,
        })
      }
    })


  },


  content_page(e){

    let id= e.currentTarget.id

    console.log(id,'本页面id')
    wx.navigateTo({
      url: `../knowledge_details/knowledge_details?id=${id}`,
    })

    wx.showLoading({
      title: '加载中...',
    })

    setTimeout(function () {
      wx.hideLoading()
      }, 3500)
  },

  DotStyle(e) {
    this.setData({
      DotStyle: e.detail.value
    })
  },
  // cardSwiper
  cardSwiper(e) {
    this.setData({
      cardCur: e.detail.current
    })
  },
  // towerSwiper
  // 初始化towerSwiper
  towerSwiper(name) {
    let list = this.data[name];
    for (let i = 0; i < list.length; i++) {
      list[i].zIndex = parseInt(list.length / 2) + 1 - Math.abs(i - parseInt(list.length / 2))
      list[i].mLeft = i - parseInt(list.length / 2)
    }
    this.setData({
      swiperList: list
    })
  },
  // towerSwiper触摸开始
  towerStart(e) {
    this.setData({
      towerStart: e.touches[0].pageX
    })
  },
  // towerSwiper计算方向
  towerMove(e) {
    this.setData({
      direction: e.touches[0].pageX - this.data.towerStart > 0 ? 'right' : 'left'
    })
  },
  // towerSwiper计算滚动
  towerEnd(e) {
    let direction = this.data.direction;
    let list = this.data.swiperList;
    if (direction == 'right') {
      let mLeft = list[0].mLeft;
      let zIndex = list[0].zIndex;
      for (let i = 1; i < list.length; i++) {
        list[i - 1].mLeft = list[i].mLeft
        list[i - 1].zIndex = list[i].zIndex
      }
      list[list.length - 1].mLeft = mLeft;
      list[list.length - 1].zIndex = zIndex;
      this.setData({
        swiperList: list
      })
    } else {
      let mLeft = list[list.length - 1].mLeft;
      let zIndex = list[list.length - 1].zIndex;
      for (let i = list.length - 1; i > 0; i--) {
        list[i].mLeft = list[i - 1].mLeft
        list[i].zIndex = list[i - 1].zIndex
      }
      list[0].mLeft = mLeft;
      list[0].zIndex = zIndex;
      this.setData({
        swiperList: list
      })
    }
  },

   /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {

  },

  toresult(e){

    console.log(e,'所有内容')

    let pic_url= e.currentTarget.dataset.item.pic_url
    let jieguo= e.currentTarget.dataset.item.jieguo
    let type=e.currentTarget.dataset.item.type
    let ocr_res=e.currentTarget.dataset.item.ocr_res

    // console.log(jieguo,'回传结果')
    console.log(type,'类型')
    
//条件判断type，如果是logo和菜品，跳转到菜品LOGO结果页；如果是文字和手写文字，跳转到文字结果页，else跳转一般结果页。
if(type=='Logo'||type=='菜品'){
  wx.navigateTo({
    url: `../logodish_result/logodish_result?pic=${pic_url}&&jieguo=${jieguo}`,
  })
  // wx.navigateTo({
  //   url: `../result/result?pic=${picurl}&&fileID=${ress.fileID}&&bindtap=${bindtap}`,
  // })
}
else if(type=='文字'||type=='手写文字'){
  wx.navigateTo({
    url: `../ocr_result/ocr_result?fileID=${pic_url}&&ocr_res=${ocr_res}`,
  })
  // wx.navigateTo({
  //   url: `../result/result?pic=${picurl}&&fileID=${ress.fileID}&&bindtap=${bindtap}`,
  // })
}
else{
    wx.navigateTo({
      url: `../result/result?fileID=${pic_url}&&jieguo=${jieguo}`,
    })
    // wx.navigateTo({
    //   url: `../result/result?pic=${picurl}&&fileID=${ress.fileID}&&bindtap=${bindtap}`,
    // })
  }
  }





})