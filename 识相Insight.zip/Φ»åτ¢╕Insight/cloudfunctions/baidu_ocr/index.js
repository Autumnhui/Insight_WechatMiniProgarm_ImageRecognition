// 云函数入口文件
const cloud = require('wx-server-sdk')

cloud.init()


var AipOcrClient = require("baidu-aip-sdk").ocr;

// 设置APPID/AK/SK
var APP_ID = "19226569";
var API_KEY = "fl1kmz5kX6FuvPgI5CHVvX4v";
var SECRET_KEY = "cKVhFi67QQQLWv8qWZtre69v9EADyG1T";

// 新建一个对象，建议只保存一个对象调用服务接口
var client = new AipOcrClient(APP_ID, API_KEY, SECRET_KEY);



// 云函数入口函数
exports.main = async (event, context) => {

  console.log(event)

  const{ fileID }=event;
  const res = await cloud.downloadFile({
    fileID:fileID
  })

  const buffer = res.fileContent;
  let image=buffer.toString("base64");

  const wenzi = await client.generalBasic(image)
  // const dongwu = await client.animalDetect(image,{baike_num:5})
  // const tongyongwuti = await client.advancedGeneral(image,{baike_num:5})
  // const dish = await client.dishDetect(image,{baike_num:5})
  // const car = await client.carDetect(image,{baike_num:5})
  // const logo = await client.logoSearch(image,{baike_num:5})
  // const huobi = await client.currency(image,{baike_num:5})
  
  return {
    wenzi,

  };
};