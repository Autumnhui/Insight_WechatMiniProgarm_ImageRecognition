// 云函数入口文件
const cloud = require('wx-server-sdk')


var AipImageClassifyClient = require("baidu-aip-sdk").imageClassify;

// 设置APPID/AK/SK
var APP_ID = "23159467";
var API_KEY = "8NFChita8yLIQBQM1q6fzqLK";
var SECRET_KEY = "8R5mb2MbKGwDyq49VXtg08Rc6wspnKhZ";

// 新建一个对象，建议只保存一个对象调用服务接口
var client = new AipImageClassifyClient(APP_ID, API_KEY, SECRET_KEY);


cloud.init()

// 云函数入口函数
exports.main = async (event, context) => {

  console.log(event)

  const{ fileID }=event;
  const res = await cloud.downloadFile({
    fileID:fileID
  })

  const buffer = res.fileContent;
  let image=buffer.toString("base64");

  // const zhiwu = await client.plantDetect(image,{baike_num:5})
  // const dongwu = await client.animalDetect(image,{baike_num:5})
  // const tongyongwuti = await client.advancedGeneral(image,{baike_num:5})
  // const dish = await client.dishDetect(image,{baike_num:5})
  // const car = await client.carDetect(image,{baike_num:5})
  const logo = await client.logoSearch(image,{baike_num:5})
  // const huobi = await client.currency(image,{baike_num:5})
  
  return {
    logo,

  };
};